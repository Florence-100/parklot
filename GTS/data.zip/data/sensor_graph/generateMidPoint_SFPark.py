#SFPark dataset
#calculate midpoint of coordinates 

#imports
import pandas as pd 
import math

#read csv 
segmentDf = pd.read_csv("sfpark_filtered_segments.csv", sep=';')

#find midpoint for each sensor id 
#just take average, assume Earth is flat since distance is small 

segmentIdList = []
midPointListX = []
midPointListY = []

for index, row in segmentDf.iterrows():
    segmentId = row['segmentid']
    startX = row['startx']
    startY =  row['starty']
    endX = row['endx']
    endY = row['endy']

    midX = (startX + endX)/2
    midY = (startY + endY)/2
    #midPointListX.append((midX*math.pi)/180)
    #midPointListY.append((midY*math.pi)/180)
    midPointListX.append(midX)
    midPointListY.append(midY)

    segmentIdList.append(segmentId)

#combine into pandas dataframe 
midpointDf = pd.DataFrame(list(zip(segmentIdList, midPointListX, midPointListY)), columns=['segmentId', 'midX', 'midY'])
midpointDf.to_csv('sfpark_segment_midpoints.csv', index=False)

