#find distance between segments 
#imports 
import pandas as pd 
#import haversine as hs
from scipy import spatial

#get data from csv 
carparkDf = pd.read_csv("Nottingham Carpark Locations.csv")
carparkIdList = carparkDf['Carpark Id'].tolist()

#find distance between each pair of points 
fromList = []
toList = []
costList = []
for startId in carparkIdList:
    for endId in carparkIdList:
        if startId != endId:
            fromList.append(startId)
            toList.append(endId)

            #find points 
            startRow = carparkDf.loc[carparkDf['Carpark Id'] == startId]
            endRow = carparkDf.loc[carparkDf['Carpark Id'] == endId]
            startPoint = (startRow['Longitude'], startRow['Latitude'])
            endPoint = (endRow['Longitude'], endRow['Latitude'])
            distance = spatial.distance.euclidean(endPoint, startPoint)
            #distance = hs.haversine(startPoint, endPoint, unit=hs.Unit.METERS)
            costList.append(distance)

#save as csv 
distanceDf = pd.DataFrame(list(zip(fromList, toList, costList)), columns=['from', 'to', 'cost'])
distanceDf.to_csv('Nottingham_carpark_distance.csv', index=False)

#save segmentIds as txt
with open("Nottingham_carparkIds.txt", "w") as file:
    for id in carparkIdList:
        file.write(str(id)+',')
