#find distance between segments 
#imports 
import pandas as pd 
import haversine as hs
from scipy import spatial

#get data from csv 
midpointDf = pd.read_csv("sfpark_segment_midpoints.csv")
segmentIdList = midpointDf['segmentId'].tolist()

#find distance between each pair of points 
fromList = []
toList = []
costList = []
for startId in segmentIdList:
    for endId in segmentIdList:
        if startId != endId:
            fromList.append(startId)
            toList.append(endId)

            #find points 
            startRow = midpointDf.loc[midpointDf["segmentId"] == startId]
            endRow = midpointDf.loc[midpointDf["segmentId"] == endId]
            startPoint = (startRow['midX'], startRow['midY'])
            endPoint = (endRow['midX'], endRow['midY'])
            distance = spatial.distance.euclidean(endPoint, startPoint)
            #distance = hs.haversine(startPoint, endPoint, unit=hs.Unit.METERS)
            costList.append(distance)

#save as csv 
distanceDf = pd.DataFrame(list(zip(fromList, toList, costList)), columns=['from', 'to', 'cost'])
distanceDf.to_csv('sfpark_segment_distance.csv', index=False)

#save segmentIds as txt
'''
with open("sfpark_segmentIds.txt", "w") as file:
    for id in  segmentIdList:
        file.write(str(id)+',')
'''

