#create csv file of time vs segment ids with capacity 

#imports 
import pandas as pd 

timeDict = {}
capacityDict = {}

#get segment id list 
midpointDf = pd.read_csv("sensor_graph/sfpark_segment_midpoints.csv")
segmentIdList = midpointDf['segmentId'].tolist()

#get dataset 
data = pd.read_csv("San_Francisco_dataset2_more.csv")

#get capacity data at each time for segment id 
for id in segmentIdList:
    timeList = []
    capacityList = []
    selectedData = data.loc[data['carparkId'] == id]
    print("Current id is:", id)
    for index, row in selectedData.iterrows():
        currentTime = row['timestamp']
        currentCapacity = row['capacity']
        timeList.append(currentTime)
        capacityList.append(currentCapacity)
    timeDict[id] = timeList
    capacityDict[id] = capacityList

availDf1 = pd.DataFrame()
availDf1['timestamp'] = timeDict[segmentIdList[0]]

colns = []
for s in segmentIdList:
    colns.append(pd.Series(capacityDict[s], name=s))
availDf2 = pd.concat(colns, names=segmentIdList, axis=1)
availDf2 = availDf2.reset_index(drop=True)

#save csv file 
capacityDf = pd.concat([availDf1, availDf2], axis=1)
capacityDf.to_csv('sfpark_timestamp_capacity_data.csv', index=False)